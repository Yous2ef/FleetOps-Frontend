export function init(root) {
  const notifyBtn = root.querySelector('#oc-notify-btn');
  if (notifyBtn) {
    notifyBtn.onclick = () => {
      notifyBtn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Notifications Enabled';
      notifyBtn.style.background = 'var(--status-success)';
      notifyBtn.disabled = true;
      syncPromoBtn();
    };
  }

  const promoBtn = root.querySelector('#oc-promo-notify-btn');
  if (promoBtn) {
    promoBtn.onclick = () => {
      promoBtn.textContent = 'Notifications On';
      promoBtn.disabled = true;
      syncMainBtn();
    };
  }

  function syncPromoBtn() {
    const pb = root.querySelector('#oc-promo-notify-btn');
    if (pb) {
      pb.textContent = 'Notifications On';
      pb.disabled = true;
    }
  }

  function syncMainBtn() {
    const mb = root.querySelector('#oc-notify-btn');
    if (mb) {
      mb.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Notifications Enabled';
      mb.style.background = 'var(--status-success)';
      mb.disabled = true;
    }
  }
}

export function destroy(root) {
  root.innerHTML = '';
}